package com.capgemini.tcc.ui;
import java.sql.SQLException;
import java.util.*;
import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.dao.PatientDAO;
import com.capgemini.tcc.service.*;;
public class Client {

	public static void main(String[] args) throws Exception {
		System.out.println("1.Add Patient Information\n2.Search Patient by Id\n3.Exit");
		Scanner sc=new Scanner(System.in);
		PatientBean pb=new PatientBean();
		PatientDAO pd=new PatientDAO();
		System.out.println("Enter your choice");
		int ch=sc.nextInt();
		switch(ch)
		 {
		 case 1:
			     System.out.println("Enter the name of the Patient:");
		         String i=sc.next();
		         System.out.println("Enter Patient Age:");
		         int j=sc.nextInt();
		         System.out.println("Enter Patient phone number:");
		         long k=sc.nextLong();
		         System.out.println("Enter Description:");
		         String  l=sc.next();
		         pb.setPatient_name(i);
		         pb.setAge(j);
		         pb.setPhone(k);
		         pb.setDescription(l);		  
		         pd.addPatientDetails(pb);

		        break; 
		        
		 case 2:
			 System.out.println("Enter Patient ID to be searched");
			 int m=sc.nextInt();
			 pd.getPatientDetails(m);
			 break;
		 case 3:
			 System.exit(0);
	default:
		System.out.println("You entered invalid choice");
	}
	}
}